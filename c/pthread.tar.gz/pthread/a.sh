#!/bin/sh
env >> a.log
date >> a.log
sleep 10
