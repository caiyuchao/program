#include <stdio.h>
int main(){
	int i= 2;
	printf("%d\n", (int *)i);
	return 0;
}
